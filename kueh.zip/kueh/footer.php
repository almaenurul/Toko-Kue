<nav class="navbar navbar-default">
  <div class="container-fluid">
    